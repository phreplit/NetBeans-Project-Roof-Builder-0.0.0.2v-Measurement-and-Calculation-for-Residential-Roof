
// Author: PHNO - Tecnólogo | Pós-Graduado
// Data Release: 05/11/2024
// Versão Código: 0.0.0.2v
// Replit: @PHNO, @PHREPLIT
// E-mail: phreplit@gmail.com

// Software: Roof Builder - 0.0.0.2v - Measurement and Calculation for Residential Roof, com GUI[interface grafica] e compilacao em ambiente desktop.

package roof.builder.software;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;
//import javafx.scene.control.Button;
//import javafx.scene.control.Label;

/**
 *
 * @author Paulo Henrique
 */
    
public class FXMLDocController implements Initializable {
    
    @FXML
    public TextField textfield;
    public TextField textfield1;
    public TextField textfield2;
    public TextField textfield3;
    public TextField textfield4;
    public TextField textfield5; 
    public TextField textfield6;
    public TextField textfield7;
    public TextField textfield8; 
    public TextField textfield9;
    public TextField textfield10;
    public TextField textfield11; 
    public TextField textfield12;
    public TextField textfield13;
    
    @FXML
    public void reset1(ActionEvent event) {
        textfield.setText("");
        textfield1.setText("");
        textfield2.setText("");
    };
    
    @FXML
    public void reset2(ActionEvent event) {
        textfield3.setText("");
        textfield4.setText("");
        textfield5.setText("");
        textfield6.setText("");
        textfield7.setText("");
    };
    
    @FXML
    public void reset3(ActionEvent event) {
        textfield8.setText("");
        textfield9.setText("");
        textfield10.setText("");
        
    };
    
    @FXML
    public void reset4(ActionEvent event) {
        textfield11.setText("");
        textfield12.setText("");
        textfield13.setText("");

    };
    
     @FXML
    public void calc_1(ActionEvent event) {
        int mult2 = Integer.parseInt(textfield.getText())*Integer.parseInt(textfield1.getText());
	textfield2.setText(String.valueOf(mult2));
    };
    
    @FXML
    public void calc_2(ActionEvent event) {
        int vartwo = 2;			                
	int mult3 = Integer.parseInt(textfield3.getText())+Integer.parseInt(textfield4.getText());
	int mult4 = mult3 / vartwo;			                
	int mult5 = Integer.parseInt(textfield5.getText())+Integer.parseInt(textfield6.getText());
	int mult6 = mult5 / vartwo;
	int result = mult4 * mult6;			                
	textfield7.setText(String.valueOf(result));
    };
    
    @FXML
    public void calc_3(ActionEvent event) {
        int mult8 = Integer.parseInt(textfield11.getText())*Integer.parseInt(textfield12.getText());
	textfield13.setText(String.valueOf(mult8));
    };
    
    @FXML
    public void sum(ActionEvent event) {
        int soma = Integer.parseInt(textfield8.getText())+Integer.parseInt(textfield9.getText());
	textfield10.setText(String.valueOf(soma));
    }
    
    @FXML
    public void sub(ActionEvent event) {
         int sub = Integer.parseInt(textfield8.getText())-Integer.parseInt(textfield9.getText());
	textfield10.setText(String.valueOf(sub));
    }
    
    @FXML
    public void div(ActionEvent event) {
         int div = Integer.parseInt(textfield8.getText())/Integer.parseInt(textfield9.getText());
	textfield10.setText(String.valueOf(div));
    }
    
    @FXML
    public void mult(ActionEvent event) {
         int mult = Integer.parseInt(textfield8.getText())*Integer.parseInt(textfield9.getText());
	textfield10.setText(String.valueOf(mult));
    }
    
    @FXML
    public void info(ActionEvent event) {
        
         StringBuilder message = new StringBuilder();
        
        message.append("\nInfo\n" 
        + "\nTo calculate the square meter of the roof with 4 equal sides [equal footage] we calculate Length x Width."
+"\nTo calculate the square meter with 4 different sides [different footage] we add the two parallel sides, "
+"\nwe add the length to the length and divide it by 2, thus taking the average, "
+"\nwe do the same with the width, we add the width to the width and divide by 2 taking the average, "
+"\nand with the results of the average of the parallel sides (width and length) "
+"\nwe multiply the two parallel sides Length x Width and thus we obtain the square meters of a roof with 4 different sides."
+"\nTo calculate the Quantity of Tiles per Square Meter: "
+"\nTaking as an example an American tile with dimensions (43Lx26W) in centimeters in horizontal axis view, "
+"\nand knowing that calculating a square meter of a roof will be L x W then 1 Square Meter = 12 tiles, "
+"\nso one square meter has 12 tiles so this will be the standard measurement. 12 x so many square meters = the amount of tiles per square meter."
+"\nTo calculate the Colonial Tile: 1 M² = 16 tiles."
+"\nTo calculate the Italian Tile: 1 M² = 14 tiles."
+"\nTo calculate the Portuguese Tile: 1 M² = 17 tiles."
+"\nTo calculate the Roman Tile: "
+"\nTaking as an example a Roman tile with dimensions (40Lx21W) in centimeters in horizontal axis view, "
+"\nand knowing that calculating a square meter of a roof will be L x W then 1 Square Meter = 16 tiles,"
+"\n so one square meter has 16 tiles so this will be the standard measurement. 16 x so many square meters = the number of tiles per square meter."
+"\nImportant Information: "
+"\nNote: This software was developed with integer variables, so it does not allow the insertion of numbers and commas. (ex: 2.90 meters change to 3 meters)."
+"\nNote: The calculation of the square meter of a residential roof in this software is done without calculating the slope. "
+"\nIf the calculation of the square meter is done with the slope, with the increase in the degree of inclination of the roof,"
+"\nThere will be an increase in the amount of tiles needed to tile and build a residential roof."
+"\nNote: the installation, construction and dimensioning of a residential roof requires a qualified and trained professional, such as a civil engineer. "
+"\nTile Pattern per Square Meter and Quantity of Tiles: "
+"\n The number of tiles can vary for more tiles or fewer tiles, depending on the dimensions of the chosen tile, "
+"\nso see that in the case of installing colonial tiles, the arrangement (fitting) of the tiles will be done with two layers of tiles, "
+"\nwhich can lead to variations (more or less) in the number of tiles needed to cover one square meter."
+"\n There is therefore a possible difference in the pattern and quantity of tiles per square meter for colonial tiles as described above."
+"\nTile Model per Square Meter and Quantity of Tiles: "
+"\n If you want to calculate a new tile model that is not in the conversion table, you will need to know the dimensions of the new tile model"
+"\nand know how many tiles will be needed to cover one square meter, so it will be (N) tiles per 1M².");
JOptionPane.showMessageDialog(null, message);

    }
    
    @FXML
    public void about(ActionEvent event) {
        StringBuilder message = new StringBuilder();
        
         message.append("\nAbout\n" 
            + "\nSoftware: Roof Builder - Measurement and Calculation for Residential Roof\n"+"\nAuthor: PHNO"+"\nData Release: 08/11/2024"+"\nVersao Codigo: 0.0.0.2v"+"\nReplit: @PHNO, @PHREPLIT"+"\nE-mail: phreplit@gmail.com");
         JOptionPane.showMessageDialog(null, message);

    }
    
    @FXML
    public void cleardata(ActionEvent event) {
        textfield.setText("");
        textfield1.setText("");
        textfield2.setText("");
        textfield3.setText("");
        textfield4.setText("");
        textfield5.setText(""); 
        textfield6.setText("");
        textfield7.setText("");
        textfield8.setText(""); 
        textfield9.setText("");
        textfield10.setText("");
        textfield11.setText(""); 
        textfield12.setText("");
        textfield13.setText("");
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
